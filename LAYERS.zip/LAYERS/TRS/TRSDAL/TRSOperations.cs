﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRS;
using TRSException;
namespace TRSDAL
{
    public class TRSOperations
    {
        static List<TRSEntity> trsList = new List<TRSEntity>();

        //To insert the TRSEntity record in TRSEntity list
        public static bool AddTRSEntity(TRSEntity trs)
        {
            bool trsAdded = false;

            try
            {
                //Adding TRSEntity object into TRSEntity list
                trsList.Add(trs);
                trsAdded = true;
            }
            catch (Exception1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsAdded;
        }

        //To modify the TRSEntity data from the list

        public static TRSEntity SearchTRSEntity(int trsNo)
        {
            TRSEntity trs = null;

            try
            {
                //Searching TRSEntity
                trs = trsList.Find(e => e.TicketNo == trsNo);
            }
            catch (Exception1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trs;
        }
    } }
