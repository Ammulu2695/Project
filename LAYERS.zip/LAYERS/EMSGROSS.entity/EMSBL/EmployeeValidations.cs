﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSGrossentity;
using EMSException;
using EMSDAL;
using System.Text.RegularExpressions;
namespace EMSBL
{
    public class EmployeeValidations
    {
        //To validate employee details
        public static bool ValidateEmployee(EMSentity emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - employee id should be 6 digit
                if (emp.EmpId < 100000 || emp.EmpId > 999999)
                {
                    empValidated = false;
                    message.Append("Employee ID should be exactly 6 digits long\n");
                }

                //Checking - employee name
                if (emp.Empname == String.Empty)
                {
                    empValidated = false;
                    message.Append("Employee Name should be provided\n");
                }
                else if (!Regex.IsMatch(emp.Empname, "[A-Z][a-z]{2,}"))
                {
                    empValidated = false;
                    message.Append("Employee Name should start with capital alphabet and it should have minimum 3 alphabets\n");
                }
                //if (emp.Salary == )
                //{
                //    empValidated = false;
                //    message.Append("Salary cannot be null");
                //}
            }
            catch (EMSException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }
        public static bool AddEmployee(EMSentity emp)
        {
            bool empAdded = false;

            try
            {
                if (ValidateEmployee(emp))
                {
                    empAdded = EmployeeOperations.AddEmployee(emp);
                }
                else
                {
                    throw new EMSException1("Please provide valid data for employee");
                }
            }
            catch (EMSException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }
    }
}
