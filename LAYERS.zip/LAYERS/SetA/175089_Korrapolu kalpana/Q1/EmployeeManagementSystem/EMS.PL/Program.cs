﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.BL;
using EMS.Entity;
using EMS.Exception;


namespace EMS.PL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Date of Creation : 8-Mar-2019
    /// Description : Business logic class for employee
    /// </summary>
    class Program
    {
        //function for registering employee
        public static void AddEmployee()
        {
            try
            {
                Employee emp = new Employee();
                Console.Write("Enter Employee ID : ");
                emp.EmployeeID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee Name : ");
                emp.EmployeeName = Console.ReadLine();
                Console.Write("Enter Employee Salary : ");
                emp.EmployeeSalary = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter Employee HRA: ");
                emp.HRA = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter Employee TA: ");
                emp.TA = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter Employee DA: ");
                emp.DA = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter Employee PF: ");
                emp.PF = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter Employee TDS: ");
                emp.TDS = Convert.ToDouble(Console.ReadLine());

                
                emp.GrossSalary = emp.Salary + emp.HRA + emp.TA + emp.DA;
                emp.TDS = (10 / 100) * emp.Salary;
                emp.NetSalary = emp.GrossSalary = (emp.PF + emp.TDS);
                //if (emp.HRA == null)
                //{
                //    emp.HRA = (20 / 100) * emp.Salary;
                //}
                //if(emp.PF==null)
                //{
                //    emp.PF = (12 / 100) * emp.Salary;
                //}
                //if(emp.TA==null)
                //{
                //    emp.TA = (10 / 100) * emp.Salary;
                //}
                //    if(emp.DA==null)
                //{

                //    emp.DA = (50 / 100) * emp.Salary;
                //}
                    
                    
                
                Console.WriteLine($"employee gross salry is:{emp.GrossSalary}");
                Console.WriteLine($"employee net salary is:{emp.NetSalary}");
                Console.WriteLine($"employee TDS:{emp.TDS}");


                bool empAdded = EmployeeValidations.AddEmployee(emp);

                if (empAdded)
                {
                    Console.WriteLine("Employee added successfully");
                }
                else
                {
                    throw new CustomerException("Employee not added");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }




        }
        //to display the employee
        public static void RetrieveEmployee()
        {
            try
            {
                List<Employee> empList = EmployeeValidations.RetrieveEmployees();

                if (empList != null || empList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Employee ID    Employee Name   Salary   HRA   TA  DA    PF     TDS   NetSalary     GrossSalary");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var emp in empList)
                    {
                        Console.WriteLine($"{emp.EmployeeID}\t\t{emp.EmployeeName}\t\t{emp.Salary}\t\t{emp.HRA}\t\t{emp.TA}\t\t{emp.DA}\t{emp.PF}\t{emp.TDS}\t{emp.NetSalary}\t{emp.GrossSalary}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Employee data not available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //serialize the employee data
        public static void SerializeEmployee()
        {
            try
            {
                bool empSerialized = EmployeeValidations.SerializeEmployee();

                if (empSerialized)
                {
                    Console.WriteLine("Employee data serialized");
                }
                else
                {
                    throw new CustomerException("Employee data not serialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Deserialize the employee data
        public static void DeserializeEmployee()
        {
            try
            {
                List<Employee> empList = EmployeeValidations.DeserializeEmployee();

                if (empList != null || empList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Employee ID    Employee Name   Salary   HRA   TA  DA    PF     TDS   NetSalary     GrossSalary");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var emp in empList)
                    {
                        Console.WriteLine($"{emp.EmployeeID}\t\t{emp.EmployeeName}\t\t{emp.Salary}\t\t{emp.HRA}\t\t{emp.TA}\t\t{emp.DA}\t{emp.PF}\t{emp.TDS}\t{emp.NetSalary}\t{emp.GrossSalary}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Employee data not available after deserialization");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Register Employee");
            Console.WriteLine("2. Display Employee");
            Console.WriteLine("3. Serialiaze Employee");
            Console.WriteLine("4. Deserialiaze Employee");
            Console.WriteLine("5.Exit");

        }

        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                    case 2:
                        RetrieveEmployee();
                        break;
                    case 3:
                        SerializeEmployee();
                        break;
                    case 4:
                        DeserializeEmployee();
                        break;
                    case 5: Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter correct choice");
                        break;

                }

            } while (choice < 6);

            Console.ReadKey();
        }
        
    }
    
}