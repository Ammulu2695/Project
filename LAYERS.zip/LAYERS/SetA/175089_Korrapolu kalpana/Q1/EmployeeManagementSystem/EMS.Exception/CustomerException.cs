﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{
    /// <summary>
    /// Employee Id:175089
    /// Employee Name:Korrapolu Kalpana
    /// Date of Creation:12-March-2019
    /// Decription:User defined exception class to handle exception of Employee
    /// </summary>
    public class CustomerException:ApplicationException
    {
        //Default Constructor
        public CustomerException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public CustomerException(string message) : base(message)
        { }
    }
}
