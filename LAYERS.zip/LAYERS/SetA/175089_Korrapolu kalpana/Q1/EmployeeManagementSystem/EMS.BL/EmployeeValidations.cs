﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.DAL;            //Reference to DAL
using EMS.Entity;       //Reference to Employee Entity
using EMS.Exception;     //Reference to Employee Exception

namespace EMS.BL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Date of Creation : 8-Mar-2019
    /// Description : Business logic class for employee
    /// </summary>
    public class EmployeeValidations
    {
        //To validate employee details
        public static bool AddEmployee(Employee emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - employee id should be 6 digit
                if (emp.EmployeeID < 100000 || emp.EmployeeID > 999999)
                {
                    empValidated = false;
                    message.Append("Employee ID should be exactly 6 digits long\n");
                }
                //Checking - employee name
                if (emp.EmployeeID == 0)
                {
                    empValidated = false;
                    message.Append("Employee ID should be provided\n");
                }
                //Checking - employee name
                if (emp.EmployeeName == String.Empty)
                {
                    empValidated = false;
                    message.Append("Employee Name should be provided\n");
                }
                //Checking - employee Salary
                if (emp.EmployeeSalary == null)
                {
                    empValidated = false;
                    message.Append("Employee Salary should be provided\n");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empValidated;
        }

        

       
        public static bool SerializeEmployee()
        {
            bool empSerialized = false;

            try
            {
                empSerialized = EmployeeOperations.SerializeEmployee();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }

        public static List<Employee> DeserializeEmployee()
        {
            List<Employee> empDesList = null;

            try
            {
                empDesList = EmployeeOperations.DeserializeEmployee();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDesList;
        }

        public static List<Employee> RetrieveEmployees()
        {
            List<Employee> empList = EmployeeOperations.RetrieveEmployees();

            return empList;
        }
    }
}
