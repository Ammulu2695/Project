﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleDetaits
{
    /// <summary>
    /// Employee Id:175089
    /// Employee Name:Korrapolu Kalpana
    /// Date of Creation:12-March-2019
    /// Description:Store the vehicle detaila in ArrayList Display in sorted Manner
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            List<Vehicle> VehicleList = new List<Vehicle>();
            
            VehicleList.Add(new Vehicle(60, "green"));
            VehicleList.Add(new Vehicle(80, "yellow"));
            VehicleList.Add(new Vehicle(120, "coffes"));
            VehicleList.Add(new Vehicle(100, "gray"));
            VehicleList.Add(new Vehicle(60, "blue"));
            VehicleList.Add(new Vehicle(60, "white"));
            VehicleComparer VehiComparer = new VehicleComparer();
            VehicleList.Sort(VehiComparer);
            foreach (var v in VehicleList)
            {
                Console.WriteLine(v.Speed+"\t" +v.Color+"\t");
            }

            List<MotorVehicle> MotorList = new List<MotorVehicle>();
            MotorList.Add(new MotorVehicle(60, "green", 5.0));
            MotorList.Add(new MotorVehicle(80, "blue", 10.0));
            MotorList.Add(new MotorVehicle(60, "gray", 8.0));
            MotorList.Add(new MotorVehicle(100, "yellow", 14.0));
            MotorList.Add(new MotorVehicle(120, "white", 6.0));
            MotorList.Sort(VehiComparer);

            Console.WriteLine();
            foreach (var m in MotorList)
            {
                Console.WriteLine(m.Speed+"\t"+m.Color+"\t"+m.FuelCapacity);
            }
            Console.ReadKey();



        }
        
    }
}
