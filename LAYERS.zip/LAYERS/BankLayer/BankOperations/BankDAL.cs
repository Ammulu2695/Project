﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankEntity;
using BankException;

namespace BankOperations
{
    public class BankDAL
    {
        static List<Bank> bankList = new List<Bank>();

        public static bool AddCustomer(Bank b)
        {
            bool custAdded = false;
            try
            {
                bankList.Add(b);
                custAdded = true;
            }
            catch(BankExceeptionClass ex) { throw ex; }
            catch(SystemException ex) { throw ex; }
            return custAdded;
        }

        public static Bank CheckBalance(int AccountNumber, Bank.AccountTypeEnum AccType)
        {
            Bank b=null;
            try
            {
                if (AccType == Bank.AccountTypeEnum.Saving)
                {
                    b = bankList.Find(e => e.SavingAccountNumber == AccountNumber);
                }
                else if (AccType == Bank.AccountTypeEnum.Current)
                {
                    b = bankList.Find(e => e.CurrentAccountNumber == AccountNumber);
                }
                else { throw new BankExceeptionClass("Can't find Account Details"); }
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

            return b;
        }

        public static Bank Withdraw(int Accno, Bank.AccountTypeEnum AccType, double Amt)
        {
            Bank b = null;
            try
            {
                if (AccType == Bank.AccountTypeEnum.Saving)
                {
                    b = bankList.Find(e => e.SavingAccountNumber == Accno);
                    CheckingWithdraw(b, Amt);
                }
                else if (AccType == Bank.AccountTypeEnum.Current)
                {
                    b = bankList.Find(e => e.CurrentAccountNumber == Accno);
                    CheckingWithdraw(b, Amt);
                }
                else { throw new BankExceeptionClass("Can't find Account Details"); }
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

            return b;
        }

        public static void CheckingWithdraw(Bank b, double Amt)
        {
            try
            {
                if (b != null)
                {
                    double bal = b.AccountBal - Amt;
                    if (bal > 500)
                    {
                        b.AccountBal = bal;
                    }
                    else { throw new BankExceeptionClass("\nCan't Withdrawn,Balance is going less than 500.You have to maintain minimum balance"); }
                }
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

        }

        public static Bank Deposit(int Accno, Bank.AccountTypeEnum AccType, double Amt)
        {
            Bank b = null;
            try
            {
                if (AccType == Bank.AccountTypeEnum.Saving)
                {
                    b = bankList.Find(e => e.SavingAccountNumber == Accno);
                    if (b != null)
                    {
                        b.AccountBal = b.AccountBal + Amt;
                    }
                }
                else if (AccType == Bank.AccountTypeEnum.Current)
                {
                    b = bankList.Find(e => e.CurrentAccountNumber == Accno);
                    if (b != null)
                    {
                        b.AccountBal = b.AccountBal + Amt;
                    }
                }
                else { throw new BankExceeptionClass("Can't find Account Details"); }

            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

            return b;
        }

        public static List<Bank> Retrieve()
        {
            return bankList;
        }
    }
}
