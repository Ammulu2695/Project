﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankException
{
    public class BankExceeptionClass : ApplicationException
    {
        public BankExceeptionClass() : base() { }

        public BankExceeptionClass(string message) : base(message) { }
    }
}
