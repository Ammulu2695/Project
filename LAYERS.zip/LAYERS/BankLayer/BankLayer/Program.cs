﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankEntity;
using BankException;
using BankValidations;

namespace BankLayer
{
    class Program
    {
        public static void PrintMenu()
        {
            Console.WriteLine("1.AddCustomer\n2.Check Balance\n3.Withdraw\n4.Deposit\n5.RetrieveAll\n6.Exit\n");
        }

        public static void AddCustomer()
        {
            try
            {
                Bank bank = new Bank();
                Console.WriteLine("\nEnter Customer Name");
                bank.CustomerName = Console.ReadLine();
                Console.WriteLine("Select Account Type");
                Console.WriteLine("1.Savings Account\n2.Current Account");
                int n = Convert.ToInt32(Console.ReadLine());
                if (n == 1)
                {
                    bank.AccountType = Bank.AccountTypeEnum.Saving;
                    Console.WriteLine("Enter Saving Account Number");
                    bank.SavingAccountNumber = Convert.ToInt32(Console.ReadLine());
                }
                else if (n == 2)
                {
                    bank.AccountType = Bank.AccountTypeEnum.Current;
                    Console.WriteLine("Enter Current Account Number");
                    bank.CurrentAccountNumber = Convert.ToInt32(Console.ReadLine());
                }
                else { throw new BankExceeptionClass("You choose Wrong Option"); }
                Console.WriteLine("Enter Account Balance");
                bank.AccountBal = Convert.ToInt32(Console.ReadLine());

                bool custAdded = ValidationBank.AddCustomer(bank);
                if(custAdded)
                    Console.WriteLine("\nCustomer Added Successfully\n");
                else
                    Console.WriteLine("Can't Add\n");
            }
            catch(BankExceeptionClass ex) { Console.WriteLine(ex.Message.ToString()); }
            catch(SystemException ex) { Console.WriteLine(ex.Message.ToString()); }
        }

        public static void CheckBalance()
        {
            Bank b = null;
            try
            {
                Console.WriteLine("\nEnter Account Number to Check Balance");
                int accno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Select Account Type");
                Console.WriteLine("1.Savings Account\n2.Current Account");
                int n = Convert.ToInt32(Console.ReadLine());
                if (n == 1)
                {
                    b = ValidationBank.CheckBalance(accno, Bank.AccountTypeEnum.Saving);
                }
                else if (n == 2)
                {
                    b = ValidationBank.CheckBalance(accno, Bank.AccountTypeEnum.Current);
                }
                else { throw new BankExceeptionClass("You choose Wrong Option"); }
                if (b != null)
                {
                    Console.WriteLine($"Customer Name is {b.CustomerName}");
                    Console.WriteLine($"Account Balance is {b.AccountBal}\n");
                }
                else
                    Console.WriteLine("Can't Find\n");
            }
            catch (BankExceeptionClass ex) { Console.WriteLine(ex.Message.ToString()); }
            catch (SystemException ex) { Console.WriteLine(ex.Message.ToString()); }
        }

        public static void Withdraw()
        {
            Bank b = null;
            try
            {
                Console.WriteLine("\nEnter Account Number to Withdraw");
                int accno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Select Account Type");
                Console.WriteLine("1.Savings Account\n2.Current Account");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Amount to Withdraw");
                double amt = Convert.ToDouble(Console.ReadLine());
                if (n == 1)
                {
                    Bank.AccountTypeEnum acctype = Bank.AccountTypeEnum.Saving;
                    b = ValidationBank.Withdraw(accno, Bank.AccountTypeEnum.Saving, amt);
                }
                else if (n == 2)
                {
                    Bank.AccountTypeEnum acctype = Bank.AccountTypeEnum.Current;
                    b = ValidationBank.Withdraw(accno, Bank.AccountTypeEnum.Current, amt);
                }
                if (b != null)
                {
                    Console.WriteLine("Withdrawn Successfully");
                    Console.WriteLine($"Updated Balance is {b.AccountBal}\n");
                }
                else
                    Console.WriteLine("Can't Withdrawn May be Low Balance\n");
            }
            catch (BankExceeptionClass ex) { Console.WriteLine(ex.Message.ToString()); }
            catch (SystemException ex) { Console.WriteLine(ex.Message.ToString()); }
        }

        public static void Deposit()
        {
            Bank b = null;
            try
            {
                Console.WriteLine("\nEnter Account Number to Deposit");
                int accno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Select Account Type");
                Console.WriteLine("1.Savings Account\n2.Current Account");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Amount to Deposit");
                double amt = Convert.ToDouble(Console.ReadLine());
                if (n == 1)
                {
                    b = ValidationBank.Deposit(accno, Bank.AccountTypeEnum.Saving, amt);
                }
                else if (n == 2)
                {
                    b = ValidationBank.Deposit(accno, Bank.AccountTypeEnum.Current, amt);
                }
                if (b != null)
                {
                    Console.WriteLine("Deposit Successfully");
                    Console.WriteLine($"Updated Balance is {b.AccountBal}\n");
                }
                else
                    Console.WriteLine("Can't Deposit May be Low Balance\n");
            }
            catch (BankExceeptionClass ex) { Console.WriteLine(ex.Message.ToString()); }
            catch (SystemException ex) { Console.WriteLine(ex.Message.ToString()); }
        }

        public static void Retrieve()
        {
            try
            {
                List<Bank> bankList = ValidationBank.Retrieve();
                if(bankList != null)
                {
                    Console.WriteLine("Customer Name\tAccount Balance\tAccount Type\tAccount Balance\n");
                    foreach (var item in bankList)
                    {
                        if (item.AccountType == Bank.AccountTypeEnum.Current)
                        {
                            Console.WriteLine($"{item.CustomerName}\t{item.CurrentAccountNumber}\t{item.AccountType}\t{item.AccountBal}\n");
                        }
                        else if (item.AccountType == Bank.AccountTypeEnum.Saving)
                        {
                            Console.WriteLine($"{item.CustomerName}\t{item.SavingAccountNumber}\t{item.AccountType}\t{item.AccountBal}\n");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("No Details Found\n");
                }
            }
            catch (BankExceeptionClass ex) { Console.WriteLine(ex.Message.ToString()); }
            catch (SystemException ex) { Console.WriteLine(ex.Message.ToString()); }
        }

        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddCustomer();
                        break;
                    case 2:
                        CheckBalance();
                        break;
                    case 3:
                        Withdraw();
                        break;
                    case 4:
                        Deposit();
                        break;
                    case 5:
                        Retrieve();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 6);
            Console.ReadKey();
        }
    }
}
