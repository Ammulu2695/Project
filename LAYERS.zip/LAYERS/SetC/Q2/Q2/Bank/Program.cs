﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Bank.BankDetails;

namespace Bank
{

    class Program
    {
        static void Main(string[] args)
        {
            try

            {

                BankDetails ba = new BankDetails();

                Console.WriteLine("account number:");

                ba.AccountNumber = int.Parse(Console.ReadLine());

                Console.WriteLine("customer name: ");

                ba.CustomerName = Console.ReadLine();
                                              
                //                Console.WriteLine(" bank balance account : ");

                //ba.Balance = double.Parse(Console.ReadLine());
                Console.WriteLine(" withdraw amount : ");
                BankDetails.Balance = 50000;
                double amt = double.Parse(Console.ReadLine());
                ba.Delevent += EventHandle;
                
                ba.WithdrawBal(amt);
            }



            catch (BalanceLimitException ce)

            {

                Console.WriteLine(ce.Message);

            }

            Console.ReadLine();


        }
    }
}
