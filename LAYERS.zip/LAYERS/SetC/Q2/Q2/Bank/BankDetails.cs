﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{// creating bankdetails of customer

    //
    public delegate void Del(string msg);
    class BankDetails
    {
        public event Del Delevent;
        int accountnumber;
                string customerName;
                double withdraw;
                       static double balance;

        public int AccountNumber // creating Account number properties
        {
            get { return accountnumber; }

            set { accountnumber = value; }

        }
                public string CustomerName // creating customer name properties

        {

            get { return customerName; }

            set { customerName = value; }

        }

        public static double Balance  // creating balance properties

        {

            get { return balance; }

            set { balance = value; }

        }
        public double Withdraw  // creating balance properties

        {

            get { return withdraw; }

            set { withdraw = value; }

        }
        //public static void Withdraw(double amount) //withdraw method
        //{
        //  if(amount<=1000) // the amount is greater than RS-1000/ otherwise it will display insufficient funds
        //    {
        //        Console.WriteLine(amount);
        //    }
        //    else
        //    {
        //        Console.WriteLine("insufficent funds");
        //    }
        //}
        public static void EventHandle(string msg)
        {
            Console.WriteLine(msg);
        }

        public void WithdrawBal(double amt)
        {
            double bal = Balance - amt;
            if (bal<1000)
            {
                if (Delevent != null)
                    EventHandle("Balance is less than 1000");
            }
            else
            {
                Balance = bal;
            }
        }

        public class BalanceLimitException : ApplicationException

        {

            public BalanceLimitException(string v) : base() { }


        }

        }
    }
