﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMS.Exception
{

    /// <summary>
    /// Employee ID :174779
    /// Employee Name :Anvesh
    /// Date of Creation : 12-Mar-2018
    /// Description : User defined exception class to handle exception of Movie Exception
    /// </summary>
    public class MovieException : ApplicationException
    {

        //Default Constructor
        public MovieException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public MovieException(string message) : base(message)
        { }

    }
}
