﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MMS.Entity;       //Reference to movie Entity
using MMS.Exception;  //Reference to movie Entity
using MMS.DAL;

using System.Text.RegularExpressions;
using System.Runtime.Serialization.Formatters.Binary;

namespace MMS.BL
{

    /// <summary>
    /// Employee ID :174779
    /// Employee Name : Anvesh
    /// Date of Creation : 12-Mar-2019
    /// Description : Business logic class for movie
    /// </summary>
    public class Validation
    {
        public static object MovieValidation { get; private set; }

        public static bool ValidateMovie(Movie m)

        {
            bool mValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {


                //Checking - movie title
                if (m.MovieTitle == String.Empty)
                {
                    mValidated = false;
                    message.Append("movie Name should be provided\n");
                }
                else if (!Regex.IsMatch(m.MovieTitle, "[A-Z][a-z]{2,}"))
                {
                    mValidated = false;
                    message.Append("Movie Name should start with capital alphabet and it should have minimum 3 alphabets\n");
                }
                //Checking released
                int MovieRelease = DateTime.Today.Year - m.MovieReleased.Year;
                if (MovieRelease < 26 / 03 / 2019)
                {
                    mValidated = false;
                    message.Append("release date should be less than or equal to today's date");
                }
                //Checking - Publisher
                if (m.Publisher == String.Empty)
                {
                    mValidated = false;
                    message.Append("Publisher Name should be provided\n");
                }
                else if (!Regex.IsMatch(m.Publisher, "[A-Z][a-z]{2,}"))
                {
                    mValidated = false;
                    message.Append("Publisher Name should start with capital alphabet and it should have minimum 3 alphabets\n");
                }

                if (m.MovieLength > 120)
                {
                    mValidated = false;
                    message.Append("As per the movie should be within 120 minutes to 160 minutes\n");
                }

                //Checking rate the Acting
                if (m.Music > 0 && m.Music > 5)
                {
                    mValidated = false;
                    message.Append("rate of Acting should be provided");
                }

                if (m.Acting > 0 && m.Acting > 5)                
                {
                    mValidated = false;
                    message.Append("rate of Acting should be provided");
                }


                if (m.Cinematography > 0 && m.Cinematography > 5)
                {
                    mValidated = false;
                    message.Append("rate of Acting should be provided");
                }
                if (mValidated == false)
                {
                    throw new MovieException(message.ToString());
                }
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mValidated;
        }
        public static bool AddMovie(Movie m)
        {
            bool mAdded = false;

            try
            {

                if (ValidateMovie(m))
                {
                    mAdded = Operation.AddMovie(m);
                }
                else
                {
                    throw new MovieException("Please provide valid data for employee");
                }
            }
                       
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mAdded;
        }
        public static List<Movie> DisplayMovie()
        {
            List<Movie> TList = Operation.DisplayMovie();

            return TList;
        }

        public static bool SerializeMovie()
        {
            bool TSerialized = false;

            try
            {
                TSerialized = Operation.SerializeMovie();
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TSerialized;
        }

        public static List<Movie> DeserializeMovie()
        {
            List<Movie> TDesList = null;

            try
            {
                TDesList = Operation.DeserializeMovie();
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TDesList;
        }
    }
}
