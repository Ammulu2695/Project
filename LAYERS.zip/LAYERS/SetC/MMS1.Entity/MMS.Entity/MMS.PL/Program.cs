﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MMS.Entity;       //Reference to Employee Entity
using MMS.Exception;
using MMS.BL;
using MMS.DAL;


//using MMS.DAL;

namespace MMS.PL
{
    class Program
    {
        public static void AddMovie()
        {
            try
            {
                Movie T = new Movie();
                Console.Write("Enter movie title : ");
                T.MovieTitle = Convert.ToString(Console.ReadLine());
                Console.Write("Enter Movie released date : ");
                T.MovieReleased = Convert.ToDateTime(Console.ReadLine());
                Console.Write("enter the publisher : ");
                T.Publisher = Console.ReadLine();
                Console.Write("enter the movie Length : ");
                T.MovieLength = Convert.ToDouble(Console.ReadLine());
                Console.Write("enter the Duration : ");
                T.Duration = Convert.ToInt32(Console.ReadLine());

                Console.Write("rate the Acting ");
                T.Acting = Convert.ToInt32(Console.ReadLine());
                Console.Write("rate the music : ");
                T.Music = Convert.ToInt32(Console.ReadLine());
                Console.Write("rate the Cinematography : ");
                T.Cinematography = Convert.ToInt32(Console.ReadLine());

                bool TAdded = Validation.ValidateMovie(T);

                if (TAdded)
                {
                    Console.WriteLine("movie added successfully");
                }
                else
                {
                    throw new MovieException("Movie not added");
                }
            }
            catch (MovieException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SerializeMovie()
        {
            try
            {
                bool TSerialized = Validation.SerializeMovie();

                if (TSerialized)
                {
                    Console.WriteLine("Movie data serialized");
                }
                else
                {
                    throw new MovieException("Movie data not serialized");
                }
            }
            catch (MovieException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeserializeMovie()
        {
            try
            {
                List<Movie> TList = Validation.DeserializeMovie();

                if (TList != null || TList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("movietitle    movieReleased   publisher   movieLength  acting   music cinematography   duration");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var T in TList)
                    {
                        Console.WriteLine($"{T.MovieTitle}\t\t{T.MovieReleased }\t{T.Publisher }\t{T.MovieLength }\t{T.Acting}\t{T.Music}\t{T.Cinematography }\t{T.Duration }");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new MovieException("Movie data not available after deserialization");
                }
            }
            catch (MovieException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DisplayMovie()
        {
            try
            {
                List<Movie> TList = Validation.DisplayMovie();

                if (TList != null || TList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("movietitle    movieReleased   publisher   movieLength  acting   music cinematography   duration");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var T in TList)
                    {
                        Console.WriteLine($"{T.MovieTitle}\t\t{T.MovieReleased }\t{T.Publisher }\t{T.MovieLength }\t{T.Acting}\t{T.Music}\t{T.Cinematography }\t{T.Duration }");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new MovieException("Employee data not available");
                }
            }
            catch (MovieException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1.Add movie ");
            // Console.WriteLine("2.display");
            //Console.WriteLine("3. Publisher");
            //Console.WriteLine("4. MovieLength");
            //Console.WriteLine("5. Acting");
            //Console.WriteLine("6. music");
            //Console.WriteLine("7. Cinematography");
            //Console.WriteLine("8. Duration");
            Console.WriteLine("2. SerializeMovie");
            Console.WriteLine("3. Deserialize Movie");
            Console.WriteLine("4.display");
            Console.WriteLine("5. Exit");
            Console.WriteLine("***********************");
        }



        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddMovie();
                        break;
                    //case 2:
                    //    AddMovieReleased();
                    //    break;
                    //case 3:
                    //    AddPublisher();
                    //    break;
                    //case 4:
                    //    AddLength();
                    //    break;
                    //case 5:
                    //    AddActing();
                    //    break;
                    //case 6:
                    //    AddMusic();
                    //    break;
                    //case 7:
                    //    Addcinematograohy();
                    //    break;
                    case 2:
                        SerializeMovie();
                        break;
                    case 3:
                        DeserializeMovie();
                        break;
                    case 4:
                        DisplayMovie();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 5);

            Console.ReadKey();
        }
    }
}

