﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMS.Entity
{

    /// <summary>
    /// Employee ID : 174779
    /// Employee Name :Anvesh
    /// Date of Creation : 12-Mar-2019
    /// Description : Entity class for Movie
    /// </summary>
    [Serializable]
    public class Movie
    {
        //Get or set  MovieTitle
        public String MovieTitle { get; set; }

        //Get or set  MovieReleased
        public DateTime MovieReleased { get; set; }

        //Get or set  Publisher 
        public string Publisher { get; set; }

        //Get or set MovieLength
        public double MovieLength { get; set; }
        //Get or set Acting
        public int Acting { get; set; }

        //Get or set Music 
        public int Music { get; set; }
        //Get or set   Cinematography
        public int Cinematography { get; set; }
        //Get or set Duration
        public int Duration { get; set; }
    }
}
