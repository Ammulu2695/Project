﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagementExcetion
{
    public class LibraryException : ApplicationException
    {
        
            //Default Constructor
            public LibraryException() : base()
            { }

            //Parameterized Constructor to initialize Message property
            public LibraryException(string message) : base(message)
            { }
        }
}
