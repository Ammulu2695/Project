﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieException
{
    public class MoviesException1:ApplicationException
    {
        //Default Constructor
        public MoviesException1() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public MoviesException1(string message) : base(message)
        { }
    }
}
