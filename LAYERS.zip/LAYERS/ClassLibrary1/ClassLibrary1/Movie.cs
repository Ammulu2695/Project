﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    [Serializable]
    public class Movie
    {
        public string Movietitle { get; set; }
        public DateTime MovieRelease { get; set; }
        public string Publisher { get; set; }
        public int Acting { get; set; }
        public int Music { get; set; }
        public int Cinematogory { get; set; }
        public int Duration { get; set; }

    }
}
