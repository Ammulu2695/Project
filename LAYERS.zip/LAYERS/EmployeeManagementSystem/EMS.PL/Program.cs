﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;       //reference to Employee Entity
using EMS.Exception;    //reference to Employee Exception
using EMS.BL;           //reference to Business operation

namespace EMS.PL
{
    class Program
    {
        public static void AddEmployee()
        {
            try
            {
                Employee emp = new Employee();
                Console.Write("Enter Employee ID : ");
                emp.EmployeeID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee Name : ");
                emp.EmployeeName = Console.ReadLine();
                Console.Write("Enter Phone Number : ");
                emp.PhoneNo = Console.ReadLine();
                Console.Write("Enter Date of Birth : ");
                emp.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter Date of Joining : ");
                emp.DOJ = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter City : ");
                emp.City = Console.ReadLine();

                bool empAdded = EmployeeValidations.AddEmployee(emp);

                if (empAdded)
                {
                    Console.WriteLine("Employee added successfully");
                }
                else
                {
                    throw new EmployeeException("Employee not added");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateEmployee()
        {
            try
            {
                Employee emp = new Employee();
                Console.Write("Enter Employee ID to be updated : ");
                emp.EmployeeID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter updated Employee Name : ");
                emp.EmployeeName = Console.ReadLine();
                Console.Write("Enter updated Phone Number : ");
                emp.PhoneNo = Console.ReadLine();
                Console.Write("Enter updated Date of Birth : ");
                emp.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter updated Date of Joining : ");
                emp.DOJ = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter updated City : ");
                emp.City = Console.ReadLine();

                bool empUpdated = EmployeeValidations.UpdateEmployee(emp);

                if (empUpdated)
                {
                    Console.WriteLine("Employee updated successfully");
                }
                else
                {
                    throw new EmployeeException("Employee not updated");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteEmployee()
        {
            try
            {
                int empID;
                Console.Write("Enter Employee ID to be Deleted : ");
                empID = Convert.ToInt32(Console.ReadLine());

                bool empDeleted = EmployeeValidations.DeleteEmployee(empID);

                if (empDeleted)
                {
                    Console.WriteLine("Employee deleted successfully");
                }
                else
                {
                    throw new EmployeeException("Employee not deleted");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchEmployee()
        {
            try
            {
                int empID;
                Console.Write("Enter Employee ID to be Searched : ");
                empID = Convert.ToInt32(Console.ReadLine());

                Employee emp = EmployeeValidations.SearchEmployee(empID);

                if (emp != null)
                {
                    Console.WriteLine($"Employee ID : {emp.EmployeeID}");
                    Console.WriteLine($"Employee Name : {emp.EmployeeName}");
                    Console.WriteLine($"Phone Number : {emp.PhoneNo}");
                    Console.WriteLine($"Date of Birth : {emp.DOB}");
                    Console.WriteLine($"Date of Joining : {emp.DOJ}");
                    Console.WriteLine($"City : {emp.City}");
                }
                else
                {
                    throw new EmployeeException("Employee not found");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveEmployee()
        {
            try
            {
                List<Employee> empList = EmployeeValidations.RetrieveEmployees();

                if (empList != null || empList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Employee ID    Employee Name   Phone Number   Date of Birth   Date of Joining   City");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var emp in empList)
                    {
                        Console.WriteLine($"{emp.EmployeeID}\t\t{emp.EmployeeName}\t{emp.PhoneNo}\t{emp.DOB}\t{emp.DOJ}\t{emp.City}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new EmployeeException("Employee data not available");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeEmployee()
        {
            try
            {
                bool empSerialized = EmployeeValidations.SerializeEmployee();

                if (empSerialized)
                {
                    Console.WriteLine("Employee data serialized");
                }
                else
                {
                    throw new EmployeeException("Employee data not serialized");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeEmployee()
        {
            try
            {
                List<Employee> empList = EmployeeValidations.DeserializeEmployee();

                if (empList != null || empList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Employee ID    Employee Name   Phone Number   Date of Birth   Date of Joining   City");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var emp in empList)
                    {
                        Console.WriteLine($"{emp.EmployeeID}\t\t{emp.EmployeeName}\t{emp.PhoneNo}\t{emp.DOB}\t{emp.DOJ}\t{emp.City}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new EmployeeException("Employee data not available after deserialization");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. Update Employee");
            Console.WriteLine("3. Delete Employee");
            Console.WriteLine("4. Search Employee");
            Console.WriteLine("5. Display Employee");
            Console.WriteLine("6. Serialize Employee");
            Console.WriteLine("7. Deserialize Employee");
            Console.WriteLine("8. Exit");
            Console.WriteLine("***********************");
        }

        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1: AddEmployee();
                        break;
                    case 2: UpdateEmployee();
                        break;
                    case 3: DeleteEmployee();
                        break;
                    case 4: SearchEmployee();
                        break;
                    case 5:RetrieveEmployee();
                        break;
                    case 6:SerializeEmployee();
                        break;
                    case 7:DeserializeEmployee();
                        break;
                    case 8:Environment.Exit(0);
                        break;
                    default:Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 8);

            Console.ReadKey();
        }
    }
}
