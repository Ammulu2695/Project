﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Date of Creation : 8-Mar-2018
    /// Description : User defined exception class to handle exception of Employee
    /// </summary>
    public class EmployeeException : ApplicationException
    {
        //Default Constructor
        public EmployeeException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public EmployeeException(string message) : base(message)
        { }
    }
}
