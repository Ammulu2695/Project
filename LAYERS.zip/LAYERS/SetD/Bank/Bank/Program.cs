﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    /// <summary>   
    /// Employee ID:174851_IN
    /// Employee Name : Karnati Rajashekar
    /// Date of Creation : 12-Mar-2019
    /// Description : Main Class for Account
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //Creating object to Account Class
            Account acc = new Account() { AccountNumber=123456, CustomerName="Rajnikanth", Balance=50005};
            
            //Adding UnderBalance Method to Event
            acc.UnderBalance += acc.UnderBalanceMethod;

            //Calling Withdraw Method
            Console.WriteLine("Enter Amount to Withdrawn");
            double amt = double.Parse(Console.ReadLine());
            acc.Withdraw(amt);
            Console.WriteLine(acc.Balance);
            //p_evt.NotifySubscriber1("vsdgvdfhtrhtrhtrh");

            Console.ReadKey();
        }
    }
}
