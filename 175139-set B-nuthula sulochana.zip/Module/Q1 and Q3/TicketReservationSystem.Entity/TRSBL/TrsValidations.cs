﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketReservationSystem.Entity;    //Reference to Entity Class Library
using TRSException;                       //Reference to Exception Class Library
using TRSDal;                          //Reference to DAL Class Library
using System.Text.RegularExpressions;
namespace TRSBL
{
    /// <summary>
    /// Employee ID : 175139
    /// Employee Name : Nuthula Sulochana
    /// Date of Creation : 2-apr-2019
    /// Description : validations for Ticket Reservation System
    /// </summary>
    public class TrsValidations
    {
        //To validate trs details
        public static bool ValidateTRS(TRSEntity trs)
        {
            bool trsValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - PNR No id should be 8 digit
                if (trs.PNRNo < 8 || trs.PNRNo > 999999999)
                {
                    trsValidated = false;
                    message.Append("PNR NO  should be start with 8 digit \n");
                }

                //Checking - trs  source name
                if (trs.Source == String.Empty)
                {
                    trsValidated = false;
                    message.Append(" source should be provided\n");
                }
                // checking trs Destination
                if (trs.Destination == String.Empty)
                {
                    trsValidated = false;
                    message.Append(" Destination  should be provided\n");
                }
               //// check date of Journy
               // if (trs.DateofJourny <= DateTime.Today)
               // {
               //     trsValidated = false;
               //     message.Append("Date of Joining should be less than or equal to today's date");
               // }
                //check the type of ticket
                if (trs.Type== string.Empty)
                {
                    trsValidated = false;
                    message.Append("Type of ticket should be provided");
                }
                else if (trs.Type.ToUpper() != "SLEEPER" &&
                        trs.Type.ToUpper() != "3AC" &&
                        trs.Type.ToUpper() != "2AC" &&
                        trs.Type.ToUpper() != "1Ac")
                {
                    trsValidated = false;
                    message.Append("Ticket should be  capital letters either SlEEPEr or 3AC or 2AC or 1AC\n");
                }
               
                if (trsValidated == false)
                {
                    throw new TicketException(message.ToString());
                }
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsValidated;
        }


             //AddTicket details
        public static bool AddTicketDetails(TRSEntity trs)
        {
            bool trsAdded = false;

            try
            {
                if (ValidateTRS(trs))
                {
                    trsAdded = TrsOperations.AddTicketDetails(trs);
                }
                else
                {
                    throw new TicketException("Please provide valid data for employee");
                }
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsAdded;
        }

       // search ticket number based PNR NO
        public static TRSEntity SearchPNRNo(int PNRNo)
        {
            TRSEntity trs= null;

            try
            {
                trs = TrsOperations.SearchPNRNo(PNRNo);
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trs;
        }
        //serialize for ticket
        public static bool SerializeTicket()
        {
            bool trsSerialized = false;

            try
            {
                trsSerialized = TrsOperations.SerializeTicket();
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsSerialized;
        }
        //Deserialize for ticket
        public static List<TRSEntity> DeserializeTicket()
        {
            List<TRSEntity> trsDesList = null;

            try
            {
                trsDesList = TrsOperations.DeserializeTicket();
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsDesList;
        }
    }

}

    

