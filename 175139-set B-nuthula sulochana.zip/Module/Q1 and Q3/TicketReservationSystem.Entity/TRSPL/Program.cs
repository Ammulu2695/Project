﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketReservationSystem.Entity;  //Reference to Entity Class Library
using TRSException;                    //Reference to Exception Class Library
using TRSBL;                             //Reference to BL Class Library
namespace TRSPL
{
    /// <summary>
    /// Employee ID : 175139
    /// Employee Name : Nuthula Sulochana
    /// Date of Creation : 2-apr-2019
    /// Description : main method for Ticket Reservation System
    /// </summary>
    class Program
    {
        //Add ticket Details
        public static void AddTicketDetails()
        {
            try
            {
                TRSEntity trs= new TRSEntity();
                Console.Write("Enter PNR No: ");
                trs.PNRNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter source : ");
                trs.Source = Console.ReadLine();
                Console.Write("Enter  destination : ");
                trs.Destination = Console.ReadLine();
                Console.Write("Enter  no oftickets : ");
                trs.NoOfTickets = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter  type : ");
                trs.Type = Console.ReadLine();



                bool trsAdded = TrsValidations.AddTicketDetails(trs);

                if (trsAdded)
                {


                    Console.WriteLine("Ticket Details  added successfully"); 
                       
                }
                else
                {
                    throw new TicketException("Movie not added");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //serach ticket based on PNR NO

        public static void SerachPNRNo()
        {
            try
            {
                int PNRNo;
                Console.Write("Enter PNR No to be Searched : ");
               PNRNo = Convert.ToInt32(Console.ReadLine());

                TRSEntity trs = TrsValidations.SearchPNRNo(PNRNo);

                if (trs!= null)
                {
                    Console.WriteLine($"Ticket PNR NO : {trs.PNRNo}");
                    Console.WriteLine($"Source Name : {trs.Source}");
                    Console.WriteLine($"Destination name : {trs.Destination}");
                    Console.WriteLine($"Date of Journy: {trs.DateofJourny}");
                    Console.WriteLine($"Type of ticket : {trs.Type}");

                    Console.WriteLine($"No of tickets : {trs.NoOfTickets}");
                }
                else
                {
                    throw new TicketException("Employee not found");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        // serializeTicket 
        public static void SerializeTicket()
        {
            try
            {
                bool trsSerialized = TrsValidations.SerializeTicket();

                if (trsSerialized)
                {
                    Console.WriteLine("Ticket data serialized");
                }
                else
                {
                    throw new TicketException("Ticket data not serialized");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Deserialize Ticket
        public static void DeserializeTicket()
        {
            try
            {
                List<TRSEntity> trsList = TrsValidations.DeserializeTicket();

                if (trsList != null || trsList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("PNR NO   Source  Name   Destination name   Date of Journy   Type   No of tickets");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var trs in trsList)
                    {
                        Console.WriteLine($"{trs.PNRNo}\t\t{trs.Source}\t{trs.Destination}\t{trs.DateofJourny}\t{trs.Type}\t{trs.NoOfTickets}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new TicketException("Ticket data not available after deserialization");
                }
            }
            catch (TicketException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        // menu of Ticket reservation system
        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Ticket Details");
            Console.WriteLine("2. Search Ticket of PNR No");
             Console.WriteLine("3. Serilization  ticket");
            Console.WriteLine("4. Deserilization ticket ");
            Console.WriteLine("5. Exit");
            Console.WriteLine("***********************");

        }
        //main method of ticket Reservation system
        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddTicketDetails();
                        break;
                    case 2:
                        SerachPNRNo();
                        break;
                    case 3:
                        SerializeTicket();
                        break;
                    case 4:
                        DeserializeTicket();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valid choice");
                        break;
                }
            } while (choice != 5);

            Console.ReadKey();
        }
    }
    }

