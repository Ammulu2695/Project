﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketReservationSystem.Entity;  //Reference to Entity Class Library
using TRSException;                   //Reference to Exception Class Library
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace TRSDal
{
    /// <summary>
    /// Employee ID : 175139
    /// Employee Name : Nuthula Sulochana
    /// Date of Creation : 2-apr-2019
    /// Description :  Operations  for Ticket Reservation
    /// </summary>
    public class TrsOperations
    {
        static List<TRSEntity> trsList = new List<TRSEntity>();

        //To insert the TRSEntity record in TRSEntity list
        public static bool AddTicketDetails(TRSEntity trs)
        {
            bool trsAdded = false;

            try
            {
                //Adding TRSEntity object into TRSEntity list
                trsList.Add(trs);
                trsAdded = true;
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsAdded;
        }

        //To modify the TRSEntity data from the list

        public static TRSEntity SearchPNRNo(int PNRNo)
        {
            TRSEntity trs= null;

            try
            {
                //Searching TRSEntity
                trs = trsList.Find(e => e.PNRNo == PNRNo);
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trs;
        }

        //To Serialize employee list
        public static bool SerializeTicket()
        {
            bool trsSerialized = false;

            try
            {
                FileStream fs= new FileStream("Ticket.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, trsList);
                fs.Close();
                trsSerialized = true;
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsSerialized;
        }

        //To deserialize employee List
        public static List<TRSEntity> DeserializeTicket()
        {
            List<TRSEntity> trsDesList = null;

            try
            {
                FileStream fs = new FileStream("Ticket.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                trsDesList = (List<TRSEntity>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (TicketException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trsDesList;
        }
    }
}


    
