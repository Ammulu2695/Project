﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketReservationSystem.Entity
{
    /// <summary>
  /// Employee ID : 175139
  /// Employee Name : Nuthula Sulochana
  /// Date of Creation : 2-apr-2019
  /// Description : Entity class for Ticket Reservation System
  /// </summary>
    [Serializable]
    public class TRSEntity
    {
        ////Get or set PNR NO
        public int PNRNo { get; set; }

        //Get or set Source
        public string Source { get; set; }

        //Get or set Destination
        public string Destination { get; set; }

        //Get or set Date of Journy
        public DateTime DateofJourny { get; set; }

        //Get or set Type
        public string Type { get; set; }

        //Get or set No of Tickets
        public double NoOfTickets { get; set; }
    }
}
