﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRSException
{
    /// <summary>
    /// Employee ID : 175139
    /// Employee Name : Nuthula Sulochana
    /// Date of Creation : 2-apr-2019
    /// Description : Exception class for Ticket Reservation System
    /// </summary>
    public class TicketException:ApplicationException
    {
        //Default Constructor
        public TicketException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public TicketException(string message) : base(message)
        { }
    }
}
