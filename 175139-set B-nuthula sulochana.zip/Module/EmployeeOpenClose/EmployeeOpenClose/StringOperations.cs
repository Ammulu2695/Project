﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeOpenClose
{
    /// <summary>
    /// Employee ID : 175139
    /// Employee Name : Nuthula Sulochana
    /// Date of Creation : 2-apr-2019
    /// Description : reflections
    // String Operations for refelction
    public class StringOperations
    {
        public static int Searchposition(string input,char searchCriteria)
        {
            int index = input.IndexOf(searchCriteria);
            return index;
        }
    }
}
