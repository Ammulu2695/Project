﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeOpenClose;
using System.Reflection;    
namespace EmployeeOpenClosed
{

    /// <summary>
    /// Employee ID : 175139
    /// Employee Name : Nuthula Sulochana
    /// Date of Creation : 2-apr-2019
    /// Description : method for Reflection of search position
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //creation of  object
            Assembly assembly = Assembly.GetExecutingAssembly();
            Type t = assembly.GetType("EmployeeOpenClose");
            MethodInfo methodInfo = t.GetMethod("Searchposition" );
            int result = (int)methodInfo.Invoke(3, new object[] {3});
            Console.WriteLine(result);
            Console.ReadLine();


        }
    }
}
